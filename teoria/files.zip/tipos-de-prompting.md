# 🎨 Tipos de Prompting: Técnicas Avançadas de Interação

## 🎯 O que você vai aprender

Existem **múltiplas técnicas de prompting** além de simplesmente "perguntar". Este guia apresenta as principais estratégias para extrair o máximo de LLMs.

## 🧠 Por que isso importa?

Diferentes tarefas exigem diferentes abordagens. Conhecer técnicas de prompting é como ter uma caixa de ferramentas — cada ferramenta para cada trabalho.

---

## 📖 As 10 Técnicas Principais

### 1️⃣ **Zero-Shot Prompting**

**Definição**: Perguntar diretamente, sem exemplos.

**Quando usar**: Tarefas simples, modelos grandes

**Exemplo**:
```
Traduza para inglês: "Bom dia, como vai?"
```

**Vantagens**: Rápido, direto  
**Limitações**: Pode ser vago para tarefas complexas

---

### 2️⃣ **Few-Shot Prompting**

**Definição**: Fornecer exemplos antes da tarefa real.

**Estrutura**:
```
[Exemplo 1] → [Resultado 1]
[Exemplo 2] → [Resultado 2]
[Exemplo 3] → [Resultado 3]
[Sua Tarefa] → [IA gera]
```

**Exemplo prático**:
```
Classifique sentimentos:

"Adorei o filme!" → Positivo
"Foi horrível" → Negativo
"Não sei, foi ok" → Neutro

"Experiência incrível mas preço alto" → ?
```

**Vantagens**: Define padrão claramente  
**Limitações**: Consome tokens do context window

---

### 3️⃣ **Chain-of-Thought (CoT)**

**Definição**: Pedir à IA para "pensar em voz alta" antes de responder.

**Prompt mágico**: "Pense passo a passo"

**Exemplo**:
```
Problema: Se João tem 3 maçãs e Maria tem o dobro de João menos 1, 
          quantas maçãs Maria tem?

❌ Sem CoT:
Resposta: 5 [pode errar]

✅ Com CoT:
"Pense passo a passo:
1. João tem 3 maçãs
2. Dobro de 3 = 6
3. 6 - 1 = 5
4. Maria tem 5 maçãs"
```

**Por quê funciona**: Force decomposição → Reduz erros

**Aplicações**: Matemática, lógica, programação

---

### 4️⃣ **Self-Consistency**

**Definição**: Gerar múltiplas respostas e escolher a mais consistente.

**Processo**:
```python
for i in range(5):
    resposta[i] = llm.generate(prompt, temperature=0.7)

resposta_final = most_common(respostas)
```

**Exemplo**:
```
Prompt: "2+2 = ?" (5 vezes)
Respostas: [4, 4, 4, 5, 4]
Resposta final: 4 (maioria)
```

**Vantagens**: Mais robusto que single-shot  
**Custo**: 5x mais tokens

---

### 5️⃣ **Tree-of-Thought (ToT)**

**Definição**: Explorar múltiplos caminhos de raciocínio como árvore de decisão.

**Estrutura**:
```
Problema
├── Abordagem A
│   ├── Sub-ideia A1
│   └── Sub-ideia A2
├── Abordagem B
│   ├── Sub-ideia B1
│   └── Sub-ideia B2
└── Abordagem C
```

**Exemplo prático**:
```
Prompt: 
"Problema: Melhorar retenção de alunos.
Explore 3 abordagens diferentes:
1. [Gamificação]
2. [Mentoria personalizada]
3. [Ajuste curricular]

Para cada abordagem, liste prós, contras e viabilidade.
Depois, sintetize a melhor estratégia combinada."
```

**Quando usar**: Problemas complexos, múltiplas soluções possíveis

---

### 6️⃣ **ReAct (Reasoning + Acting)**

**Definição**: Combinar raciocínio com ações externas (busca, cálculos, APIs).

**Ciclo**:
```
1. Thought: "Preciso saber a população do Brasil"
2. Action: [Busca web]
3. Observation: "215 milhões"
4. Thought: "Agora posso calcular..."
5. Answer: [Resposta final]
```

**Exemplo**:
```
Pergunta: Qual país tem maior população: Brasil ou Nigéria?

Thought: Não tenho certeza das populações atuais
Action: search("população Brasil 2024")
Observation: ~215 milhões
Action: search("população Nigéria 2024")
Observation: ~223 milhões
Thought: Nigéria tem população maior
Answer: Nigéria (223M vs 215M)
```

**Aplicação**: Agentes autônomos, RAG systems

---

### 7️⃣ **Prompt Chaining**

**Definição**: Dividir tarefa complexa em prompts sequenciais.

**Estrutura**:
```
Prompt 1: [Subtarefa A] → Output A
Prompt 2: [Usa Output A + Subtarefa B] → Output B
Prompt 3: [Usa Output B + Subtarefa C] → Output Final
```

**Exemplo**:
```
Prompt 1: "Liste 10 tópicos sobre IA"
Output: [lista de tópicos]

Prompt 2: "Para cada tópico, escreva 1 parágrafo"
Output: [10 parágrafos]

Prompt 3: "Combine em artigo coeso com intro e conclusão"
Output: [artigo completo]
```

**Vantagens**: Controle fino, qualidade melhor  
**Custo**: Múltiplas chamadas de API

---

### 8️⃣ **Meta-Prompting**

**Definição**: Pedir à IA para gerar/melhorar prompts.

**Exemplo 1 - Geração**:
```
"Crie um prompt que faça a IA explicar fotossíntese para uma 
 criança de 8 anos, usando apenas analogias do cotidiano."

Output da IA:
"Imagine que a planta é uma fábrica de comida que funciona 
 com luz do sol..."
```

**Exemplo 2 - Otimização**:
```
"Este é meu prompt: [prompt atual]
Como posso melhorá-lo para obter respostas mais precisas?"
```

**Quando usar**: Você não sabe como formular bem a pergunta

---

### 9️⃣ **Role-Prompting**

**Definição**: Atribuir uma persona/especialização à IA.

**Estrutura**:
```
"Você é um [ROLE] com [EXPERTISE]. 
[CONTEXTO]. [TAREFA]."
```

**Exemplos**:
```
"Você é um psicólogo clínico com 20 anos de experiência 
 em TCC. Explique reestruturação cognitiva para um paciente 
 iniciante."

"Você é um professor de física que adora usar metáforas. 
 Explique relatividade para um adolescente."

"Você é um crítico de cinema especializado em Hitchcock. 
 Analise este filme sob perspectiva hitchcockiana."
```

**Por quê funciona**: Ancora o "espaço semântico" da resposta

---

### 🔟 **Recursive Prompting**

**Definição**: Usar output como input para refinar iterativamente.

**Processo**:
```
Iteração 1: Prompt inicial → Output básico
Iteração 2: "Melhore isso: [Output 1]" → Output refinado
Iteração 3: "Agora adicione exemplos: [Output 2]" → Output final
```

**Exemplo**:
```
Round 1:
"Escreva introdução sobre IA"
→ [parágrafo genérico]

Round 2:
"Torne esta introdução mais engajante e use uma analogia"
→ [parágrafo melhorado]

Round 3:
"Adicione estatística recente e transição para próximo tópico"
→ [parágrafo polido]
```

**Custo**: Alto (múltiplas iterações)  
**Benefício**: Qualidade máxima

---

## 🔬 Comparação de Técnicas

| Técnica | Complexidade | Custo (tokens) | Qualidade | Quando usar |
|---------|--------------|----------------|-----------|-------------|
| Zero-Shot | Baixa | Baixo | Média | Tarefas simples |
| Few-Shot | Média | Médio | Alta | Definir padrões |
| Chain-of-Thought | Média | Médio | Alta | Raciocínio lógico |
| Self-Consistency | Média | Alto | Muito Alta | Decisões críticas |
| Tree-of-Thought | Alta | Muito Alto | Máxima | Problemas complexos |
| ReAct | Alta | Alto | Alta | Agentes, automação |
| Prompt Chaining | Alta | Alto | Muito Alta | Workflows complexos |
| Meta-Prompting | Baixa | Baixo | Variável | Exploração |
| Role-Prompting | Baixa | Baixo | Média-Alta | Especialização |
| Recursive | Alta | Muito Alto | Máxima | Refinamento |

---

## 🛠️ Template Híbrido (Combinando Técnicas)

```
[ROLE]
Você é um [especialista] com [contexto]

[FEW-SHOT]
Exemplos do estilo desejado:
- Exemplo 1
- Exemplo 2

[CHAIN-OF-THOUGHT]
Pense passo a passo:
1. [etapa 1]
2. [etapa 2]
3. [etapa 3]

[TAREFA]
[descrição específica]

[FORMATO]
Responda em [formato desejado]

[RESTRIÇÕES]
Não [o que evitar]
```

---

## 📚 Referências

### Papers Fundacionais
- **"Chain-of-Thought Prompting"** – Wei et al. (2022)
- **"Tree of Thoughts"** – Yao et al. (2023)
- **"ReAct"** – Yao et al. (2023)
- **"Self-Consistency"** – Wang et al. (2022)

### Recursos
- **Prompt Engineering Guide**: [promptingguide.ai](https://www.promptingguide.ai)
- **OpenAI Cookbook**: [cookbook.openai.com](https://cookbook.openai.com)
- **LangChain Docs**: [python.langchain.com](https://python.langchain.com)

---

## ➡️ Próximos Passos

1. **[Psicologia do Prompt Eficaz](psicologia-do-prompt-eficaz.md)** → Fundamentos comunicacionais
2. **[Temperatura e Parâmetros](temperatura-e-parametros.md)** → Ajuste fino de outputs
3. **Pratique no [Prompt Mestre 2.0](../prompts/prompt-mestre-2.0.md)**

---

**Escrito por Gabriel, Arquiteto Cognitivo**  
*Última atualização: Dezembro 2024*
