# 📚 Teoria: Fundamentos de IA Generativa

Bem-vindo à biblioteca teórica do ecossistema de IA Generativa! Esta pasta contém guias aprofundados sobre conceitos fundamentais, técnicas avançadas e aplicações práticas.

---

## 🗺️ Mapa de Navegação

### 🔧 Fundamentos Técnicos
Entenda **como** a IA funciona por dentro:

1. **[Como Funcionam os LLMs](como-funcionam-os-llms.md)** ⭐ *Comece aqui*
   - Tokens, embeddings, attention, parâmetros
   - O processo completo: da pergunta à resposta
   - Limitações técnicas fundamentais

2. **[O que são Embeddings](o-que-sao-embeddings.md)**
   - Representação vetorial de significado
   - Aritmética semântica ("Rei - Homem + Mulher = Rainha")
   - Vieses codificados em vetores

3. **[Temperatura e Parâmetros](temperatura-e-parametros.md)**
   - Controlando criatividade vs. previsibilidade
   - Frequency/presence penalty
   - Guia de configurações por tipo de tarefa

4. **[Context Window Explicado](context-window-explicado.md)**
   - Limites de memória da IA
   - Estratégias para gerenciar contexto longo
   - Paralelos com memória humana

---

### 🧠 Psicologia & IA
Conexões entre cognição humana e artificial:

5. **[Vieses Cognitivos em LLMs](vieses-cognitivos-em-llms.md)** ⭐ *Essencial para psicólogos*
   - Como LLMs herdam preconceitos humanos
   - Viés de confirmação, estereotipagem, ancoragem
   - Experimentos práticos de detecção

6. **[Metacognição Assistida por IA](metacognicao-assistida-por-ia.md)** ⭐ *Único e inovador*
   - IA como espelho do seu pensamento
   - Técnicas de autoconhecimento aumentado
   - Análise de padrões cognitivos

7. **[Psicologia do Prompt Eficaz](psicologia-do-prompt-eficaz.md)** ⭐ *Ponte essencial*
   - Princípios de comunicação humana aplicados a IA
   - Enquadramento, ancoragem, teoria da mente
   - Templates psicologicamente informados

8. **[Antropomorfização de IAs](antropomorfizacao-de-ias.md)**
   - Por que tratamos máquinas como humanas
   - Efeito ELIZA e viés de agência
   - Consequências práticas e éticas

---

### 🎨 Técnicas de Prompting
Domine interações avançadas:

9. **[Tipos de Prompting](tipos-de-prompting.md)** ⭐ *Guia prático*
   - Zero-shot, Few-shot, Chain-of-Thought
   - Tree-of-Thought, ReAct, Self-Consistency
   - Comparação e casos de uso

---

### ⚖️ Ética & Sociedade
Implicações morais e sociais:

10. **[Ética no Uso de IA](etica-no-uso-de-ia.md)** ⭐ *Obrigatório*
    - 6 princípios éticos fundamentais
    - Privacidade, atribuição, não-maleficência
    - Checklist ético para uso responsável

11. **[IA na Saúde Mental](ia-na-saude-mental.md)** ⭐ *Para psicólogos*
    - Chatbots terapêuticos, detecção de crises
    - Promessas e perigos específicos
    - Guia de uso ético para profissionais

---

## 📊 Por Onde Começar?

### Se você é **iniciante em IA**:
```
1. Como Funcionam os LLMs
2. Psicologia do Prompt Eficaz
3. Tipos de Prompting
4. Ética no Uso de IA
```

### Se você é **psicólogo interessado em IA**:
```
1. Vieses Cognitivos em LLMs
2. Metacognição Assistida por IA
3. IA na Saúde Mental
4. Antropomorfização de IAs
```

### Se você quer **dominar prompting**:
```
1. Psicologia do Prompt Eficaz
2. Tipos de Prompting
3. Temperatura e Parâmetros
4. Context Window Explicado
```

### Se você é **desenvolvedor/técnico**:
```
1. Como Funcionam os LLMs
2. O que são Embeddings
3. Context Window Explicado
4. Temperatura e Parâmetros
```

---

## 🎯 Características de Cada Arquivo

Todos os guias seguem estrutura consistente:

- **🎯 O que você vai aprender**: Resumo executivo
- **🧠 Por que isso importa**: Relevância prática
- **📖 Explicação**: Conteúdo principal com analogias
- **🔍 Exemplo Prático**: Casos de uso reais
- **🤔 Questões para Reflexão**: Para aprofundar
- **🛠️ Experimentos**: Testes práticos
- **📚 Referências**: Papers, livros, recursos
- **➡️ Próximos Passos**: Links para conteúdos relacionados

---

## 🔄 Fluxo de Aprendizagem Sugerido

```
FASE 1: Fundamentos (1-2 semanas)
├── Como Funcionam os LLMs
├── Psicologia do Prompt Eficaz
└── Ética no Uso de IA

FASE 2: Aprofundamento (2-3 semanas)
├── Vieses Cognitivos em LLMs
├── Tipos de Prompting
├── Temperatura e Parâmetros
└── Context Window Explicado

FASE 3: Especialização (conforme interesse)
├── Psicólogos → IA na Saúde Mental + Metacognição
├── Técnicos → Embeddings + Arquitetura Avançada
└── Criadores → Prompting Avançado + Aplicações
```

---

## 💡 Dicas de Estudo

1. **Não leia linearmente**: Siga seus interesses e necessidades
2. **Faça os experimentos**: Conhecimento teórico sem prática é limitado
3. **Conecte com sua área**: Cada guia tem aplicações específicas
4. **Questione sempre**: As "Questões para Reflexão" não têm respostas definitivas
5. **Documente descobertas**: Mantenha um diário de aprendizagem

---

## 🤝 Contribuindo

Este material é vivo e em evolução. Se você:
- Encontrar erros ou imprecisões
- Tiver sugestões de novos tópicos
- Quiser compartilhar experimentos
- Desenvolver aplicações interessantes

Abra uma issue ou pull request no repositório!

---

## 📬 Contato

Dúvidas, sugestões ou discussões sobre o conteúdo:
- **GitHub Issues**: Para questões técnicas
- **Discussões**: Para debate conceitual

---

## 🎓 Filosofia do Projeto

Este não é um curso "neutro" sobre IA. É um guia **crítico, psicologicamente informado e eticamente consciente**.

Rejeitamos:
- ❌ Hype acrítico ("IA resolverá tudo!")
- ❌ Tecnofobia desinformada ("IA destruirá a humanidade!")
- ❌ Superficialidade ("10 truques de prompt")

Abraçamos:
- ✅ Compreensão profunda de mecanismos
- ✅ Análise crítica de limitações e vieses
- ✅ Aplicação ética e responsável
- ✅ Integração com conhecimento humano existente

**IA é ferramenta poderosa. Use com sabedoria.**

---

**Última atualização**: Dezembro 2024  
**Criado por**: Gabriel, Arquiteto Cognitivo  
**Licença**: MIT (consulte LICENSE.md)
